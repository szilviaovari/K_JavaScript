const szolgaltatasSelect = document.getElementById("szolgaltatasSelect");
const kezelesSelect = document.getElementById("kezelesSelect");
const szakemberSelect = document.getElementById("szakemberSelect");
const idopontSelect = document.getElementById("idopontSelect");
const uzenet = document.getElementById("uzenet");

// ki kell üríteni a selectet
function resetSelect(select, placeholder) {
  select.innerHTML = `<option value="">${placeholder}</option>`;
  select.disabled = true;
}

//szolgáltatások betöltése
async function loadSzolgaltatasok() {
  try {
    const res  = await fetch("/szolgaltatasok");
    const data = await res.json();

    data.forEach((s) => {
      szolgaltatasSelect.innerHTML += `<option value="${s.id}">${s.nev}</option>`;
    });

    szolgaltatasSelect.disabled = false;
  } catch (err) {
    showUzenet("Hiba: a szerver nem érhető el.", "hiba");
  }
}

loadSzolgaltatasok();

//majd utána a kezelések betöltése
szolgaltatasSelect.addEventListener("change", async function () {
  resetSelect(kezelesSelect,   "Válassz kezelést");
  resetSelect(szakemberSelect, "Válassz szakembert");
  resetSelect(idopontSelect,   "Válassz időpontot");

  if (!this.value) return;

  const res  = await fetch(`/kezelesek/${this.value}`);
  const data = await res.json();

  data.forEach((k) => {
    kezelesSelect.innerHTML += `<option value="${k.id}">${k.nev}</option>`;
  });

  kezelesSelect.disabled = false;
});

//majd utána a szakemberek betöltése
kezelesSelect.addEventListener("change", async function () {
  resetSelect(szakemberSelect, "Válassz szakembert");
  resetSelect(idopontSelect,   "Válassz időpontot");

  if (!this.value) return;

  const res  = await fetch(`/szakemberek/${this.value}`);
  const data = await res.json();

  data.forEach((sz) => {
    szakemberSelect.innerHTML += `<option value="${sz.id}">${sz.nev}</option>`;
  });

  szakemberSelect.disabled = false;
});

//majd utána a időpont betöltése
szakemberSelect.addEventListener("change", async function () {
  resetSelect(idopontSelect, "Válassz időpontot");

  if (!this.value) return;

  const res  = await fetch(`/idopontok/${this.value}`);
  const data = await res.json();

  if (data.length === 0) {
    idopontSelect.innerHTML = `<option value="">Nincs szabad időpont</option>`;
    return;
  }

  data.forEach((i) => {
    idopontSelect.innerHTML += `<option value="${i.id}">${i.datum}</option>`;
  });

  idopontSelect.disabled = false;
});

async function saveBooking() {
  const nev   = document.getElementById("nev").value.trim();
  const email = document.getElementById("email").value.trim();

  if (!nev || !email || !szolgaltatasSelect.value || !kezelesSelect.value ||
      !szakemberSelect.value || !idopontSelect.value) {
    showUzenet("Kérjük, töltsd ki az összes mezőt!", "hiba");
    return;
  }

  const body = {
    nev,
    email,
    szolgaltatas_id: +szolgaltatasSelect.value,
    kezeles_id:      +kezelesSelect.value,
    szakember_id:    +szakemberSelect.value,
    idopont_id:      +idopontSelect.value,
  };

  try {
    const res  = await fetch("/foglalasok", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(body),
    });
    const data = await res.json();

    if (res.ok) {
      showUzenet(data.message, "siker");
      //kiválasztott időpont eltüntetése a listából
      idopontSelect.querySelector(`option[value="${body.idopont_id}"]`)?.remove();
      
      document.getElementById("nev").value   = "";
      document.getElementById("email").value = "";
    } else {
      showUzenet(data.message, "hiba");
    }
  } catch (err) {
    showUzenet("Szerverhiba történt.", "hiba");
  }
}

//üzenet megjelenítése
function showUzenet(szoveg, tipus) {
  uzenet.textContent  = szoveg;
  uzenet.className    = `uzenet ${tipus}`;
  uzenet.style.display = "block";
  setTimeout(() => { uzenet.style.display = "none"; }, 4000);
}
