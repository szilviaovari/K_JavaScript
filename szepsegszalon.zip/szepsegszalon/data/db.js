import Database from "better-sqlite3";

const db = new Database("./data/szepsegszalon.db");

db.prepare(
  `
  CREATE TABLE IF NOT EXISTS szolgaltatasok (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nev TEXT
  )
`,
).run();

db.prepare(
  `
  CREATE TABLE IF NOT EXISTS kezelesek (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    szolgaltatas_id INTEGER,
    nev TEXT
  )
`,
).run();

db.prepare(
  `
  CREATE TABLE IF NOT EXISTS szakemberek (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kezeles_id INTEGER,
    nev TEXT
  )
`,
).run();

db.prepare(
  `
  CREATE TABLE IF NOT EXISTS idopontok (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    szakember_id INTEGER,
    datum TEXT,
    foglalt INTEGER DEFAULT 0
  )
`,
).run();

db.prepare(
  `
  CREATE TABLE IF NOT EXISTS foglalasok (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nev TEXT,
    email TEXT,
    szolgaltatas_id INTEGER,
    kezeles_id INTEGER,
    szakember_id INTEGER,
    idopont_id INTEGER
  )
`,
).run();

export function getAllSzolgaltatasok() {
  return db.prepare(`SELECT * FROM szolgaltatasok`).all();
}

export function getSzolgaltatasById(id) {
  return db.prepare(`SELECT * FROM szolgaltatasok WHERE id = ?`).get(id);
}

export function getKezelesekBySzolgaltatas(szolgaltatas_id) {
  return db
    .prepare(`SELECT * FROM kezelesek WHERE szolgaltatas_id = ?`)
    .all(szolgaltatas_id);
}

export function getKezelesById(id) {
  return db.prepare(`SELECT * FROM kezelesek WHERE id = ?`).get(id);
}

export function getSzakemberekByKezeles(kezeles_id) {
  return db
    .prepare(`SELECT * FROM szakemberek WHERE kezeles_id = ?`)
    .all(kezeles_id);
}

export function getSzakemberById(id) {
  return db.prepare(`SELECT * FROM szakemberek WHERE id = ?`).get(id);
}

export function getIdopontokBySzakember(szakember_id) {
  return db
    .prepare(`SELECT * FROM idopontok WHERE szakember_id = ? AND foglalt = 0`)
    .all(szakember_id);
}

export function getIdopontById(id) {
  return db.prepare(`SELECT * FROM idopontok WHERE id = ?`).get(id);
}

export function setIdopontFoglalt(id) {
  return db.prepare(`UPDATE idopontok SET foglalt = 1 WHERE id = ?`).run(id);
}

export function getAllFoglalasok() {
  return db
    .prepare(
      `
    SELECT
      f.id,
      f.nev,
      f.email,
      sz.nev AS szolgaltatas,
      k.nev AS kezeles,
      sp.nev AS szakember,
      i.datum AS idopont
    FROM foglalasok f
    JOIN szolgaltatasok sz ON sz.id = f.szolgaltatas_id
    JOIN kezelesek k ON k.id  = f.kezeles_id
    JOIN szakemberek sp ON sp.id = f.szakember_id
    JOIN idopontok i ON i.id  = f.idopont_id
  `,
    )
    .all();
}

export function createFoglalas(
  nev,
  email,
  szolgaltatas_id,
  kezeles_id,
  szakember_id,
  idopont_id,
) {
  const result = db
    .prepare(
      `
    INSERT INTO foglalasok (nev, email, szolgaltatas_id, kezeles_id, szakember_id, idopont_id)
    VALUES (?, ?, ?, ?, ?, ?)
  `,
    )
    .run(nev, email, szolgaltatas_id, kezeles_id, szakember_id, idopont_id);
  return result;
}

export function deleteFoglalas(id) {
  return db.prepare(`DELETE FROM foglalasok WHERE id = ?`).run(id);
}

const { szam } = db
  .prepare(`SELECT COUNT(*) AS szam FROM szolgaltatasok`)
  .get();

if (szam === 0) {
  db.prepare(
    `INSERT INTO szolgaltatasok (nev) VALUES ('Kozmetika'), ('Körmök'), ('Szempilla')`,
  ).run();

  db.prepare(
    `
    INSERT INTO kezelesek (szolgaltatas_id, nev) VALUES
    (1, 'Arctisztítás'),
    (1, 'Hydra kezelés'),
    (2, 'Géllakk'),
    (2, 'Műköröm'),
    (3, '1D Szempilla'),
    (3, '2D Szempilla')
  `,
  ).run();

  db.prepare(
    `
    INSERT INTO szakemberek (kezeles_id, nev) VALUES
    (1, 'Kiss Anna'),
    (1, 'Nagy Réka'),
    (2, 'Szabó Laura'),
    (3, 'Kovács Nóra'),
    (4, 'Varga Dorina'),
    (5, 'Molnár Dóra'),
    (6, 'Balogh Lili')
  `,
  ).run();

  db.prepare(
    `
    INSERT INTO idopontok (szakember_id, datum) VALUES
    (1, '2026-06-20 10:00'),
    (1, '2026-06-20 12:00'),
    (2, '2026-06-21 09:00'),
    (3, '2026-06-22 14:00'),
    (4, '2026-06-23 15:00'),
    (5, '2026-06-24 16:00'),
    (6, '2026-06-25 11:00'),
    (7, '2026-06-26 13:00')
  `,
  ).run();
}

export default db;
