import Database from "better-sqlite3";
const db = new Database("./data/sports.db");

//ellenorzeskent
export const getAllequipments = () =>
  db.prepare(`SELECT * FROM equipments`).all();

export const getEquipmentById = (id) =>
  db.prepare(`SELECT *FROM equipments WHERE id=?`).get(id);

export const getEquipmentByCategory = (category) =>
  db.prepare(`SELECT *FROM equipments WHERE category=?`).all(category);

export const updateEquipment = (name, category, brand, price, quantity, id) =>
  db
    .prepare(
      `UPDATE equipments SET name=?, category=?, brand=?, price=?, quantity=? WHERE id=?`,
    )
    .run(name, category, brand, price, quantity, id);

export const deleteEquipment = (id) =>
  db.prepare(`DELETE FROM equipments WHERE id=?`).run(id);
