import express from "express";
import * as db from "./data/db.js";

const PORT = 3000;
const app = express();

//ellenorzeskent
app.use(express.json());
app.get("/api/equipments", (req, res) => {
  const equipments = db.getAllequipments();
  res.json(equipments);
});

app.get("/api/equipment/:id", (req, res) => {
  const id = +req.params.id;
  const equipment = db.getEquipmentById(id);
  if (!equipment) {
    return res.status(404).json({ message: "Equipment not found." });
  }
  res.json(equipment);
});

app.get("/api/equipment/category/:category", (req, res) => {
  const category = req.params.category;
  const equipment = db.getEquipmentByCategory(category);
  if (!equipment) {
    return res.status(404).json({ message: "Equipment not found." });
  }
  res.json(equipment);
});

app.put("/api/equipment/:id", (req, res) => {
  const id = +req.params.id;
  const { name, category, brand, price, quantity } = req.body;
  const equipment = db.getEquipmentById(id);
  if (!equipment) {
    return res.status(404).json({ message: "Equipment not found." });
  }
  if (
    !name ||
    !category ||
    !brand ||
    price == undefined ||
    quantity == undefined
  ) {
    return res.status(400).json({ message: "Minden mezőt töltsön ki" });
  }
  if (price <= 0 || (quantity != 0 && quantity != 1)) {
    return res.status(400).json({ message: "Helytelen adatok" });
  }
  db.updateEquipment(name, category, brand, price, quantity, id);
  res.status(200).json({
    message: "Sikeres módosítás",
    name,
    category,
    brand,
    price,
    quantity,
    id,
  });
});

app.delete("/api/equipment/:id", (req, res) => {
  const id = +req.params.id;
  const equipment = db.getEquipmentById(id);
  if (!equipment) {
    return res.status(404).json({ message: "Equipment not found." });
  }
  db.deleteEquipment(id);
  res.status(200).json({ message: "Equipment successfully deleted." });
});

app.listen(PORT, console.log(`Server runs on ${PORT}`));
