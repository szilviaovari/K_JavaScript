import express from "express";
import * as db from "./data/db.js";

const PORT = 3000;
const app = express();

app.use(express.json());

app.get("/employees", (req, res) => {
  const employees = db.getAllEmployees();
  res.status(200).json(employees);
});

app.get("/employees/:id", (req, res) => {
  const employee = db.getEmployeeById(+req.params.id);
  if (employee) {
    return res.status(404).json({ message: "Employee not found" });
  }
  res.status(200).json(employee);
});

app.post("/employees", (req, res) => {
  const company = req.body.company;
  const lastname = req.body.lastname;
  const firstname = req.body.firstname;
  const position = req.body.position;
  const salary = req.body.salary;
  const department = req.body.department;
  const gender = req.body.gender;
  const holiday_days = req.body.holiday_days;
  const birth_date = req.body.birth_date;
  if (
    !company ||
    !lastname ||
    !firstname ||
    !position ||
    !salary ||
    !department ||
    !gender ||
    !holiday_days ||
    !birth_date
  ) {
    return res.status(400).json({ message: "These information are requied." });
  }
  const saved = db.saveEmployee(
    company,
    lastname,
    firstname,
    position,
    salary,
    department,
    gender,
    holiday_days,
    birth_date,
  );
  res.status(201).json({
    id: saved.lastInsertRowid,
    company,
    lastname,
    firstname,
    position,
    salary,
    department,
    gender,
    holiday_days,
    birth_date,
  });
});

app.put("/employees/:id", (req, res) => {
  const employee = db.getEmployeeById(+req.params.id);
  if (employee) {
    return res.status(404).json({ message: "Employee not found" });
  }
  const company = req.body.company;
  const lastname = req.body.lastname;
  const firstname = req.body.firstname;
  const position = req.body.position;
  const salary = req.body.salary;
  const department = req.body.department;
  const gender = req.body.gender;
  const holiday_days = req.body.holiday_days;
  const birth_date = req.body.birth_date;
  if (
    !company ||
    !lastname ||
    !firstname ||
    !position ||
    !salary ||
    !department ||
    !gender ||
    !holiday_days ||
    !birth_date
  ) {
    return res.status(400).json({ message: "These information are requied." });
  }
  const update = db.updateEmloyee(
    id,
    company,
    lastname,
    firstname,
    position,
    salary,
    department,
    gender,
    holiday_days,
    birth_date,
  );
  res.status(200).json({ message: "Update success", update });
});

app.delete("/employees/:id", (req, res) => {
  const employee = db.getEmployeeById(+req.params.id);
  if (employee) {
    return res.status(404).json({ message: "Employee not found" });
  }
  db.deleteEmployee(id);
  return res.status(200).json({ message: "Employee deleted successfully." });
});

app.listen(PORT, () => console.log(`Servers runs on ${PORT}`));
