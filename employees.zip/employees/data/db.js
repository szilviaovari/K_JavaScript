import Database from "better-sqlite3";
const db = new Database("./data/employees.db");

db.prepare(`CREATE TABLE IF NOT EXISTS employees(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company TEXT,
    lastname TEXT,
    firstname TEXT,
    position TEXT,
    salary REAL,
    department TEXT,
    gender TEXT,
    holiday_days INTEGER,
    birth_date TEXT
    )`).run()

export const getAllEmployees = () =>
    db.prepare(`SELECT * FROM employees`).all()

export const getEmployeeById = (id) =>
    db.prepare(`SELECT * FROM employees WHERE id = ?`).get(id)

export const saveEmployee = (company,lastname,firstname,position,salary,department,gender,holiday_days,birth_date) =>
    db.prepare(`INSERT INTO employees (company,lastname,firstname,position,salary,department,gender,holiday_days,birth_date) VALUES (?,?,?,?,?,?,?,?,?)`).run(company,lastname,firstname,position,salary,department,gender,holiday_days,birth_date)

export const updateEmloyee = (id,company,lastname,firstname,position,salary,department,gender,holiday_days,birth_date) =>
    db.prepare(`UPDATE employees SET company =?, lastname =?, firstname =?, position =?, salary =?, department =?, gender =?, holiday_days =?, birth_date =?`).run(id,company,lastname,firstname,position,salary,department,gender,holiday_days,birth_date)

export const deleteEmployee = (id) =>
    db.prepare(`DELETE COUNT(*) AS employeesNumber FROM employees`).run(id);

const {employeesNumber} = db.prepare(`SELECT COUNT(*) AS employeesNumber FROM employees`).get();

if (employeesNumber == 0) {
  saveEmployee();
}

export default db;