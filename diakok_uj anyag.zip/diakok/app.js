import express from "express";
import usersRoutes from "./routes/users.js";

const PORT = 3030;
const app = express();

app.use(express.json());

app.use("/students", usersRoutes);

app.listen(PORT, () => {
  console.log(`Server runs on http://localhost:${PORT}`);
});


//post nal
//const saved = db.saveStudent(name)
//res status(201).json({id: saved.lastInsertRowid, name})


//put nál
//db.updateStudent(id, name)