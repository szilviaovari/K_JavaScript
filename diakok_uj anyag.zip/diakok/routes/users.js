// import {
//   getAllStudents,
//   getUserById,
//   saveUser,
//   updateUser,
// } from "../controllers/users.js";
import * as userController from "../controllers/users.js";

// import express from "express";
// const router = express.router();
import { Router } from "express";
const router = Router();

app.get("/", userController.getAllStudents);

app.get("/:id", userController.getUserById);

app.post("/", userController.saveUser);

app.put("/:id", userController.updateUser);
//hianyzik a delete

export default router;
