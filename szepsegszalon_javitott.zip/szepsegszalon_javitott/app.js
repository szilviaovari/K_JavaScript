import express from "express";
import { dirname } from "path";
import { fileURLToPath } from "url";

import {
  getAllSzolgaltatasok,
  getKezelesekBySzolgaltatas,
  getSzakemberekByKezeles,
  getIdopontokBySzakember,
  getIdopontById,
  setIdopontFoglalt,
  getAllFoglalasok,
  createFoglalas,
  deleteFoglalas,
} from "./data/db.js";

const __dirname = dirname(fileURLToPath(import.meta.url)); //az API hostolja/kiszolgálja a weboldalt
const PORT = 3000;
const app = express();

app.use(express.json());
app.use(express.static(__dirname));

app.get("/szolgaltatasok", (req, res) => {
  const data = getAllSzolgaltatasok();
  res.json(data);
});

app.get("/kezelesek/:szolgaltatas_id", (req, res) => {
  const data = getKezelesekBySzolgaltatas(+req.params.szolgaltatas_id);
  res.json(data);
});

app.get("/szakemberek/:kezeles_id", (req, res) => {
  const data = getSzakemberekByKezeles(+req.params.kezeles_id);
  res.json(data);
});


app.get("/idopontok/:szakember_id", (req, res) => {
  const data = getIdopontokBySzakember(+req.params.szakember_id);
  res.json(data);
});


app.get("/foglalasok", (req, res) => {
  const data = getAllFoglalasok();
  res.json(data);
});

app.post("/foglalasok", (req, res) => {
  const {
    nev,
    megjegyzes,
    szolgaltatas_id,
    kezeles_id,
    szakember_id,
    idopont_id,
  } = req.body;

  if (!nev || !szolgaltatas_id || !kezeles_id || !szakember_id || !idopont_id) {
    return res
      .status(400)
      .json({ message: "Kérjük töltsd ki a kötelező mezőket!" });
  }

  const idopont = getIdopontById(+idopont_id);
  if (!idopont) {
    return res.status(404).json({ message: "Nem létező időpont!" });
  }
  if (idopont.foglalt === 1) {
    return res.status(409).json({ message: "Ez az időpont már foglalt!" });
  }

  createFoglalas(
    nev,
    megjegyzes || "",
    +szolgaltatas_id,
    +kezeles_id,
    +szakember_id,
    +idopont_id,
  );
  setIdopontFoglalt(+idopont_id);//időpont megjelölése foglaltként

  res.status(201).json({ message: "Foglalás sikeresen mentve!" });
});

app.delete("/foglalasok/:id", (req, res) => {
  const result = deleteFoglalas(+req.params.id);
  if (result.changes === 0) {
    return res.status(404).json({ message: "Nincs ilyen foglalás!" });
  }
  res.json({ message: "Foglalás törölve." });
});

app.listen(PORT, () => {
  console.log(`Szerver fut: http://localhost:${PORT}`);
});
