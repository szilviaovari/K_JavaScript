import Database from "better-sqlite3";

const db = new Database("./data/szepsegszalon.sqlite");

db.prepare(
  `
  CREATE TABLE IF NOT EXISTS szolgaltatasok (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nev TEXT
  )
`,
).run();

db.prepare(
  `
  CREATE TABLE IF NOT EXISTS kezelesek (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    szolgaltatas_id INTEGER,
    nev TEXT
  )
`,
).run();

db.prepare(
  `
  CREATE TABLE IF NOT EXISTS szakemberek (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kezeles_id INTEGER,
    nev TEXT
  )
`,
).run();

db.prepare(
  `
  CREATE TABLE IF NOT EXISTS idopontok (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    szakember_id INTEGER,
    datum TEXT,
    foglalt INTEGER DEFAULT 0
  )
`,
).run();

db.prepare(
  `
  CREATE TABLE IF NOT EXISTS foglalasok (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nev TEXT,
    megjegyzes TEXT,
    szolgaltatas_id INTEGER,
    kezeles_id INTEGER,
    szakember_id INTEGER,
    idopont_id INTEGER
  )
`,
).run();

export function getAllSzolgaltatasok() {
  return db.prepare(`SELECT * FROM szolgaltatasok`).all();
}

export function getSzolgaltatasById(id) {
  return db.prepare(`SELECT * FROM szolgaltatasok WHERE id = ?`).get(id);
}

export function getKezelesekBySzolgaltatas(szolgaltatas_id) {
  return db
    .prepare(`SELECT * FROM kezelesek WHERE szolgaltatas_id = ?`)
    .all(szolgaltatas_id);
}

export function getKezelesById(id) {
  return db.prepare(`SELECT * FROM kezelesek WHERE id = ?`).get(id);
}

export function getSzakemberekByKezeles(kezeles_id) {
  return db
    .prepare(`SELECT * FROM szakemberek WHERE kezeles_id = ?`)
    .all(kezeles_id);
}

export function getSzakemberById(id) {
  return db.prepare(`SELECT * FROM szakemberek WHERE id = ?`).get(id);
}

export function getIdopontokBySzakember(szakember_id) {
  return db
    .prepare(`SELECT * FROM idopontok WHERE szakember_id = ? AND foglalt = 0`)
    .all(szakember_id);
}

export function getIdopontById(id) {
  return db.prepare(`SELECT * FROM idopontok WHERE id = ?`).get(id);
}

export function setIdopontFoglalt(id) {
  return db.prepare(`UPDATE idopontok SET foglalt = 1 WHERE id = ?`).run(id);
}

export function setIdopontSzabad(id) {
  return db.prepare(`UPDATE idopontok SET foglalt = 0 WHERE id = ?`).run(id);
}

export function getAllFoglalasok() {
  return db
    .prepare(
      `
    SELECT
      f.id,
      f.nev,
      f.megjegyzes,
      sz.nev AS szolgaltatas,
      k.nev AS kezeles,
      sp.nev AS szakember,
      i.datum AS idopont
    FROM foglalasok f
    JOIN szolgaltatasok sz ON sz.id = f.szolgaltatas_id
    JOIN kezelesek k ON k.id  = f.kezeles_id
    JOIN szakemberek sp ON sp.id = f.szakember_id
    JOIN idopontok i ON i.id  = f.idopont_id
  `,
    )
    .all();
}

export function createFoglalas(
  nev,
  megjegyzes,
  szolgaltatas_id,
  kezeles_id,
  szakember_id,
  idopont_id,
) {
  const result = db
    .prepare(
      `
    INSERT INTO foglalasok (nev, megjegyzes, szolgaltatas_id, kezeles_id, szakember_id, idopont_id)
    VALUES (?, ?, ?, ?, ?, ?)
  `,
    )
    .run(
      nev,
      megjegyzes,
      szolgaltatas_id,
      kezeles_id,
      szakember_id,
      idopont_id,
    );
  return result;
}

export function deleteFoglalas(id) {
  const foglalas = db
    .prepare(`SELECT idopont_id FROM foglalasok WHERE id = ?`)
    .get(id);
  if (!foglalas) return { changes: 0 };
  //feszabadítjuk az időpontot
  db.prepare(`UPDATE idopontok SET foglalt = 0 WHERE id = ?`).run(
    foglalas.idopont_id,
  );
  return db.prepare(`DELETE FROM foglalasok WHERE id = ?`).run(id);
}

const { szam } = db
  .prepare(`SELECT COUNT(*) AS szam FROM szolgaltatasok`)
  .get();

if (szam === 0) {
  db.prepare(
    `INSERT INTO szolgaltatasok (nev) VALUES ('Kozmetika'), ('Körmök'), ('Szempilla')`,
  ).run();

  db.prepare(
    `
    INSERT INTO kezelesek (szolgaltatas_id, nev) VALUES
    (1, 'Arctisztítás'),
    (1, 'Hydra kezelés'),
    (2, 'Géllakk'),
    (2, 'Műköröm'),
    (3, '1D Szempilla'),
    (3, '2D Szempilla')
  `,
  ).run();

  db.prepare(
    `
    INSERT INTO szakemberek (kezeles_id, nev) VALUES
    (1, 'Kiss Anna'),
    (1, 'Nagy Réka'),
    (1, 'Kovács Anna'),
    (2, 'Szabó Laura'),
    (2, 'Nagy Éva'),
    (3, 'Kovács Nóra'),
    (3, 'Tóth Katalin'),
    (3, 'Szabó Zsuzsanna'),
    (4, 'Varga Dorina'),
    (4, 'Horváth Erzsébet'),
    (5, 'Molnár Dóra'),
    (6, 'Balogh Lili'),
    (6, 'Varga Júlia')
  `,
  ).run();

  db.prepare(
    `
    INSERT INTO idopontok (szakember_id, datum) VALUES
    (1, '2026-06-05 14:00'),
    (1, '2026-06-12 11:00'),
    (1, '2026-06-18 17:00'),
    (1, '2026-06-20 12:00'),
    
    (2, '2026-06-24 09:00'),
    (2, '2026-06-22 10:00'),
    (2, '2026-06-21 11:00'),
    (2, '2026-06-25 12:00'),

    (3, '2026-06-26 14:00'),
    (3, '2026-06-23 15:00'),
    (3, '2026-06-24 16:00'),
    (3, '2026-06-22 17:00'),

    (4, '2026-06-28 15:00'),
    (4, '2026-06-23 16:00'),
    (4, '2026-06-27 11:00'),
    (4, '2026-06-26 13:00'),

    (5, '2026-06-26 16:00'),
    (5, '2026-06-25 11:00'),
    (5, '2026-06-28 13:00'),
    (5, '2026-06-27 14:00'),

    (6, '2026-06-05 11:00'),
    (6, '2026-06-26 13:00'),
    (6, '2026-06-12 14:00'),
    (6, '2026-06-28 15:00'),

    (7, '2026-06-26 16:00'),
    (7, '2026-06-27 09:00'),
    (7, '2026-06-06 17:00'),
    (7, '2026-06-29 15:00')
  `,
  ).run();
}

export default db;
